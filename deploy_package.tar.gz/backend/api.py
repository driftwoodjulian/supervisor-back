from flask import Flask, jsonify, request, make_response
from flask_cors import CORS
from backend.database import EvalSession, SourceSession, init_db, SessionLocal, SourceSessionLocal
from backend.models import Evaluation, Chat, User
import os
import jwt
import datetime
from functools import wraps
from werkzeug.security import check_password_hash

app = Flask(__name__)
CORS(app)

SECRET_KEY = "super_secret_key" # In production, this goes in .env
app.config['SECRET_KEY'] = SECRET_KEY

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        try:
            token = token.split(" ")[1] # Bearer <token>
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
        except Exception as e:
            return jsonify({'message': 'Token is invalid!'}), 401
        return f(*args, **kwargs)
    return decorated

@app.route('/api/chats/<int:chat_id>', methods=['GET'])
@token_required
def get_chat_details(chat_id):
    session = SessionLocal()
    # In a real app with two DBs (Postgres and SQLite), this is tricky.
    # The Chat/Message data is in Postgres (Source), but we are in the Backend which connects to both.
    # backend/database.py handles this.
    
    # Logic:
    # 1. Fetch Chat metadata from Source DB (Postgres)
    # 2. Fetch Messages from Source DB (Postgres)
    
    # We need a new Session for the Source DB.
    # See backend/database.py for how to do this.
    # For now, let's look at how orchestrator does it, or if we need to expose SourceSession.
    
    from backend.database import SourceSessionLocal
    import json
    # Local import to avoid circular dependency if any, though likely fine at top too.
    from backend.models import Message
    source_session = SourceSessionLocal()
    
    chat = source_session.query(Chat).filter(Chat.id == chat_id).first()
    # Correct column name is chatId, and order by createdAt
    messages = source_session.query(Message).filter(Message.chatId == chat_id).order_by(Message.createdAt).all()
    
    source_session.close()
    session.close()
    
    if not chat:
        return jsonify({"error": "Chat not found"}), 404
        
    # Helper to determine role from author JSON
    formatted_messages = []
    for i, m in enumerate(messages):
        author_data = m.author
        print(f"DEBUG MSG {i}: AuthorType={type(author_data)}, Data={author_data}")
        
        # Logic from legacy 'get_messages.py':
        # dict -> support operator (agent)
        # str -> customer
        role = "agent"
        if isinstance(author_data, str):
            role = "customer"
        elif isinstance(author_data, dict):
             # Some dicts might still be customers? 
             # Legacy code said: explicit dict check is operator. 
             # But let's verify if there's an edge case. 
             # For now, sticking to legacy: dict=agent, str=customer.
             role = "agent" 

        formatted_messages.append({
            "index": i + 1, # Add index for UI reference
            "role": role,
            "content": m.text,
            "created_at": m.createdAt.isoformat() if m.createdAt else None,
            "author_name": author_data.get('pushName') if isinstance(author_data, dict) else author_data
        })

    return jsonify({
        "chat": {
            "id": chat.id,
            "created_at": chat.createdAt.isoformat() if chat.createdAt else None,
            "closed_at": chat.closedAt.isoformat() if chat.closedAt else None,
            "display_name": chat.displayName,
            "metadata": chat.msg_metadata # Directly pass JSON metadata
        },
        "messages": formatted_messages
    })

@app.route('/api/login', methods=['POST'])
def login():
    auth = request.json
    if not auth or not auth.get('username') or not auth.get('password'):
        return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login required!"'})

    session = SessionLocal()
    user = session.query(User).filter_by(username=auth.get('username')).first()
    session.close()

    if not user:
         return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login required!"'})

    if check_password_hash(user.password_hash, auth.get('password')):
        token = jwt.encode({
            'user': user.username,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
        }, app.config['SECRET_KEY'], algorithm="HS256")

        return jsonify({'token': token})

    return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login required!"'})

@app.route('/api/evaluations', methods=['GET'])
@token_required
def get_evaluations():
    session = EvalSession()
    source_session = SourceSessionLocal() # Need to check open status
    
    try:
        # 1. Get IDs of currently OPEN chats from Source DB
        # User Requirement: "if a displayed chat is closed then it is eliminated"
        open_chats = source_session.query(Chat.id).filter(Chat.closedAt == None).all()
        open_chat_ids = [c.id for c in open_chats]
        
        # 2. Fetch latest evaluations, but FILTER by open_chat_ids
        if not open_chat_ids:
             return jsonify([])

        # Using IN clause to filter
        evals = session.query(Evaluation)\
            .filter(Evaluation.chat_id.in_(open_chat_ids))\
            .order_by(Evaluation.created_at.desc())\
            .limit(50).all()
            
        result = []
        for e in evals:
            result.append({
                "chat_id": e.chat_id,
                "score": e.score,
                "reason": e.reason,
                "improvement": e.improvement,
                "key_messages": e.key_messages,
                "created_at": e.created_at.isoformat()
            })
        return jsonify(result)
    finally:
        session.close()
        source_session.close()

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=int(os.getenv('BACKEND_PORT', 5001)))
