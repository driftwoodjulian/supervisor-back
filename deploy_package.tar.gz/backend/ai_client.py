import json
import random
import os
import requests
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

class AIClient:
    def __init__(self):
        self.host_b_ip = os.getenv("HOST_B_IP", "127.0.0.1")
        self.base_url = f"http://{self.host_b_ip}:8000/v1"
        self.simulate = os.getenv("SIMULATE_AI", "False").lower() == "true"
        self.model_name = "supervisor-ai"

        self.system_prompt = (
            "You are a B2C/B2B satisfaction expert. Evaluate the support agent's performance.\n"
            "- OUTPUT: Strictly a valid JSON object.\n"
            "- SCORE: Must be EXACTLY ONE of: 'horrible', 'bad', 'neutral', 'good', 'great'.\n"
            "- LANGUAGE: The 'reason' and 'improvement' fields MUST be in SPANISH.\n\n"
            "### OUTPUT JSON SCHEMA:\n"
            "{\n"
            "  \"score\": \"string (exactly one of: horrible, bad, neutral, good, great)\",\n"
            "  \"reason\": \"Spanish text (max 500 chars) explaining the choice.\",\n"
            "  \"improvement\": \"Spanish text (max 800 chars) on how the operator can improve.\",\n"
            "  \"key_messages\": [int, int] // INDICES of agent messages that triggered the score.\n"
            "  // CRITICAL: If score is 'bad' or 'horrible', 'key_messages' MUST contain at least one message index.\n"
            "}\n"
        )

    def evaluate_chat(self, history):
        """
        Sends chat history to AI Host and returns parsed JSON evaluation.
        History should be a list of dicts: [{'role': 'user'|'agent', 'content': '...', 'timestamp': '...', 'author_name': '...'}]
        """
        if self.simulate:
            print("AI Client: SIMULATION MODE")
            return self._test_response()

        formatted_conversation = self._format_conversation_with_time(history)
        
        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": formatted_conversation}
            ],
            "temperature": 0.0,
            "max_tokens": 2048
        }

        try:
            print(f"Sending request to AI Host: {self.base_url}")
            response = requests.post(f"{self.base_url}/chat/completions", json=payload, timeout=40)
            response.raise_for_status()
            
            result = response.json()
            if not result or 'choices' not in result or not result['choices']:
                 raise Exception(f"Invalid API response: {result}")

            # Handling for reasoning models or incomplete responses
            msg = result["choices"][0]["message"]
            content = msg.get("content")
            
            # If content is None, check if the model put the answer in 'reasoning_content' or 'reasoning'
            # (Some models do this when they time out or misbehave)
            if content is None:
                print(f"DEBUG: Content is None. Checking reasoning fields...")
                content = msg.get("reasoning_content") or msg.get("reasoning")
            
            if content is None:
                print(f"DEBUG: AI returned None content. Raw result: {result}")
                raise Exception("AI returned empty/null content")
            
            # Clean up content to ensure it's just JSON
            content = self._extract_json(content)
            parsed_result = json.loads(content)
            
            # Ensure required fields exist
            return {
                "score": parsed_result.get("score") or "unknown",
                "reason": parsed_result.get("reason") or "No reason provided",
                "improvement": parsed_result.get("improvement") or "No improvement provided",
                "key_messages": parsed_result.get("key_messages") or []
            }

        except Exception as e:
            print(f"AI Client Error: {e}")
            # Fallback must return a valid structure for the DB
            return {
                "score": "unknown", 
                "reason": f"AI Connection Failure: {str(e)}",
                "improvement": "Check Host B connection.",
                "key_messages": []
            }

    def _extract_json(self, text):
        if text is None:
             return "{}"
        # Fallback to find the last JSON object (borrowed logic from old project)
        try:
            # Try direct parse
            json.loads(text)
            return text
        except:
            pass
            
        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1:
            return text[start:end+1]
        return "{}"

    def _format_time_diff(self, prev_time, curr_time):
        if not prev_time or not curr_time:
            return ""
        try:
            if isinstance(prev_time, str):
                dt1 = datetime.fromisoformat(prev_time)
            else:
                dt1 = prev_time

            if isinstance(curr_time, str):
                dt2 = datetime.fromisoformat(curr_time)
            else:
                dt2 = curr_time

            diff = dt2 - dt1
            seconds = diff.total_seconds()
            
            prefix = "+"
            if seconds < 0:
                prefix = "-"
                seconds = abs(seconds)
                
            if seconds < 60:
                return f" ({prefix}{int(seconds)}s)"
            elif seconds < 3600:
                minutes = int(seconds / 60)
                return f" ({prefix}{minutes}m)"
            else:
                hours = int(seconds / 3600)
                return f" ({prefix}{hours}h)"
        except Exception:
            return ""

    def _format_conversation_with_time(self, messages_list):
        formatted_lines = []
        last_time = None
        last_operator_name = None
        
        for i, m in enumerate(messages_list):
            # Safe get for models.Message which might not be a dict
            if isinstance(m, dict):
                current_time = m.get("timestamp")
                author = m.get("author", {}) or {}
                author_name = author.get("name") if isinstance(author, dict) else None
                role = m.get("role", "user")
                content = m.get("content", "")
            else:
                # If it's a SQLAlchemy object, attributes accessed differently
                # But Orchestrator seems to pass a cleaned dict or we need to adjust Orchestrator
                # Let's assume Orchestrator passes logical objects.
                # Actually, Orchestrator line 48: history = [{"role": ..., "content": ...}] without timestamps.
                # We need to update Orchestrator to pass full context.
                return "Error: Message format update required."

            # Calculate time diff
            time_str = ""
            if last_time and current_time:
                time_str = self._format_time_diff(last_time, current_time)
                
            role_label = role.capitalize()
            
            if role == "agent" and author_name:
                role_label = f"Support agent ({author_name})"
                if last_operator_name and last_operator_name != author_name:
                     formatted_lines.append(f"[System: Conversation transferred from {last_operator_name} to {author_name}]")
                last_operator_name = author_name
                
            line = f"{i+1} - {role_label}{time_str}: {content}"
            formatted_lines.append(line)
            
            if current_time:
                last_time = current_time
                
        return "\n".join(formatted_lines)

    def _test_response(self):
        return {
            "score": random.choice(["horrible", "bad", "neutral", "good", "great"]),
            "reason": "Evaluación simulada: El agente respondió correctamente pero podría haber sido más rápido.",
            "improvement": "Se sugiere utilizar plantillas de respuesta para agilizar la atención.",
            "key_messages": [1, 3]
        }
