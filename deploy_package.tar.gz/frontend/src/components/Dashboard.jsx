import React, { useState, useEffect } from 'react';
import { getEvaluations } from '../api';
import { removeToken } from '../auth';
import ScoreCard from './ScoreCard';
import ChatModal from './ChatModal';

const Dashboard = ({ onLogout }) => {
    const [evals, setEvals] = useState([]);
    const [modalState, setModalState] = useState({ show: false, chatId: null, data: {} });

    // Polling logic
    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = await getEvaluations();
                // Ensure data is an array
                if (Array.isArray(data)) {
                    setEvals(data);
                }
            } catch (err) {
                if (err.status === 401) {
                    removeToken();
                    onLogout(); // Trigger parent logout
                }
            }
        };

        fetchData(); // Initial load
        const interval = setInterval(fetchData, 5000);
        return () => clearInterval(interval);
    }, [onLogout]);

    const handleViewDetails = (chatId, reason, improvement, keyMessages) => {
        setModalState({
            show: true,
            chatId,
            data: { reason, improvement, keyMessages }
        });
    };

    const handleCloseModal = () => {
        setModalState(prev => ({ ...prev, show: false }));
    };

    // Grouping Logic
    const groups = {
        Great: [], Good: [], Neutral: [], Bad: [], Horrible: [], Unknown: []
    };

    evals.forEach(item => {
        let score = (typeof item.score === 'object' && item.score) ? item.score.score : item.score;
        if (typeof score !== 'string') score = 'Unknown';

        let capScore = score.charAt(0).toUpperCase() + score.slice(1).toLowerCase();
        if (groups[capScore]) groups[capScore].push(item);
        else groups.Unknown.push(item);
    });

    const sections = ['Great', 'Good', 'Neutral', 'Bad', 'Horrible', 'Unknown'];

    return (
        <>
            <div className="app-header">
                <h1>SUPERVISOR AI</h1>
                <p>Live B2B/B2C Evaluation Stream</p>
                <div style={{ position: 'absolute', top: '20px', right: '20px' }}>
                    <button onClick={() => { removeToken(); onLogout(); }} className="btn btn-sm btn-outline-danger">LOGOUT</button>
                </div>
            </div>

            <div className="score-container">
                {evals.length === 0 && <div className="loading-spinner">Initializing Uplink...</div>}

                {sections.map(key => {
                    const items = groups[key];
                    if (!items || items.length === 0) return null;
                    return (
                        <div key={key} className="score-section">
                            <div className="score-section-header">
                                <span className={`score-badge score-${key.toLowerCase()} mb-0`}>{key}</span>
                                <span>{items.length} Chats</span>
                            </div>
                            <div className="score-cards-grid">
                                {items.map((item, idx) => (
                                    <ScoreCard
                                        key={idx}
                                        item={item}
                                        onViewDetails={handleViewDetails}
                                    />
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div >

            <ChatModal
                show={modalState.show}
                onHide={handleCloseModal}
                chatId={modalState.chatId}
                initialData={modalState.data}
            />
        </>
    );
};

export default Dashboard;
