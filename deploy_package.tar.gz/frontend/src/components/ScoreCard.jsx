import React from 'react';

const ScoreCard = ({ item, onViewDetails }) => {
    // Parse inner score object if needed
    const scoreObj = (typeof item.score === 'object' && item.score !== null) ? item.score : { score: item.score };
    const score = scoreObj.score || "Unknown";
    const reason = item.reason || scoreObj.reason || "No reason provided";
    const improvement = item.improvement || scoreObj.improvement;
    const keyMessages = item.key_messages || scoreObj.key_messages || [];

    // Map score to CSS class
    let scoreClass = 'score-unknown';
    if (typeof score === 'string') {
        if (score.toLowerCase() === 'great') scoreClass = 'score-great';
        if (score.toLowerCase() === 'good') scoreClass = 'score-good';
        if (score.toLowerCase() === 'neutral') scoreClass = 'score-neutral';
        if (score.toLowerCase() === 'bad') scoreClass = 'score-bad';
        if (score.toLowerCase() === 'horrible') scoreClass = 'score-horrible';
    }

    return (
        <div className="score-card">
            <span className={`score-badge ${scoreClass}`}>{score}</span>
            <div className="chat-id">Chat #{item.chat_id}</div>
            <div className="chat-reason" style={{ height: '60px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {reason}
            </div>
            <button
                className="btn btn-primary w-100 btn-sm"
                onClick={() => onViewDetails(item.chat_id, reason, improvement, keyMessages)}
            >
                View Transcript
            </button>
        </div>
    );
};

export default ScoreCard;
